package csc319.j4.employeeassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAssignmentApplicationTests {

    @Test
    void contextLoads() {
    }

}
