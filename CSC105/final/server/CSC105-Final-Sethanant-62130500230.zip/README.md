# CSC105 - Final - Room Reservation

*Sethanant Pipatpakorn 62130500230*

### /index.jsp

> The default webpage of this web application which server the user who want to create and submit new room reservation request.

### /advisor.jsp

> A page that allow the advisor to review all the request. You could either select approve or disapprove the request. It's on purpose that there is no link to this page from any other pages because this page should be use for advisor only.

### /status.jsp

> A summary page for administrator or general users to see the status of the requests. The administration officer could use that page to perform manual room reservation on their system.

