### Please provide the environment variables to make this application function properly

> MSSQL_HOST: Host of the MSSQL database
>
> MSSQL_DB: The name of database
>
> MSSQL_USER: The database user
>
> MSSQL_PASSWORD: The password of the user